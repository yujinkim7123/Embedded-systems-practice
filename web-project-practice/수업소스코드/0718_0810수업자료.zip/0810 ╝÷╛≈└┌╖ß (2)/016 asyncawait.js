// async function homework(){
//   if(어떤 비동기 작업){
//     const a = await 1;
//   }
//   console.log(a)
// }

// homework()

