const obj = {
  width:100,
  height:200,
}

const obj2 = {
  color: 'red'
}

const obj3 = {

}