// const arr = [1,2,3]
const arr2 = [4,5]

// arr에 arr2를 넣기로하자.
//
const arr = [1,2,3, ...arr2]