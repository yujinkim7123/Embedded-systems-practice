const a = "김"
const b = "싸피"

console.log(a+b)

console.log(`${a}${b}`)