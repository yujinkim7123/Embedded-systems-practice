const arr = [1, "1", function test(){}]

console.log(arr[1])

// const zero = arr[0];
// const one = arr[1];
// const two = arr[2];

const [zero,sadsadsa,two] = arr;
// 배열에서는 순서가 보장된다
// 객체가 배열보다 갖는 장점이 무엇인가?
