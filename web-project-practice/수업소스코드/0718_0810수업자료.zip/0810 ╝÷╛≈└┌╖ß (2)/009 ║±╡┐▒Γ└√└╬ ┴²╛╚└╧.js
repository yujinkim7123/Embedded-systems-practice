setTimeout(() => {
  console.log("빨래");
},3000);
console.log("설거지");