// 문자열.replace("찾을 문자열", "대체할 문자열")

const str = "BBQBbQMINBbQ";

const result = str.replace("BBQBbQMINBbQ", "ABC");
console.log(result);

// 상세 조건을 부여할때 정규 표현식
// /문자/flag 형태
// flag는 g 플래그가 붙으면 패턴과 일치하는 모든것을 찾는다
// g가 빠지면 맨 처음부분만 변경
// i가 붙으면 대소문자 없이 검색한다.
// .은 아무 문자에나 일치
const result1 = str.replace(/BQ/g, "HC");
console.log(result);

const result2 = str.replace(/BQ/g, "HC");
console.log(result);


