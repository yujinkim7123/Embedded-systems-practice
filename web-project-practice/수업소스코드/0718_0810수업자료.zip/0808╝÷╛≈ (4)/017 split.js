let str = "BTS ABC BBQ MC";
let a = str.split(" ");
alert(a);