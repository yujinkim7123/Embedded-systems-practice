const a = "AAA";
const b = "BBB";
const c = "CCC";

const result = a + b + c;

console.log(result)