class Hero {
    constructor() {
        this.HP = 100;
    }
    run(){
        this.HP = this.HP - 10;
        console.log(this.HP)
    }
}

class SuperMan extends Hero{
    fly() {
        console.log("fly")
    }
}

const superman = new SuperMan();

superman.fly()
superman.run()