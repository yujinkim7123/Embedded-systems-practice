// 객체는 임의로 속성을 추가하는게 가능

const ssafy = {
    number: 99,
    eat() {
        return this.number + 5;
    },
    run() {
        return this.number - 10;
    },
    show() {
        console.log(this.number);
    },
    test: () => {
        console.log(this)
    }
}

ssafy.eat()
ssafy.run()
ssafy.show()
ssafy.test()
ssafy.name = "김싸피"
console.log(ssafy)