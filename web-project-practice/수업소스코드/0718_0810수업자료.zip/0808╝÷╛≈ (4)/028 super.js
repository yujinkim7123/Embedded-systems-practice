class Hero {
    constructor() {
        this.HP = 100;
    }
    run(){
        this.HP = this.HP - 10;
        console.log(this.HP)
    }
    walk() {
     console.log("걷기")   
    }
}

class SuperMan extends Hero{
    constructor(hp, mp) {
        super(hp)
        this.hp = hp
        this.mp = mp
    }
    walk() {
        super.walk()
        console.log("빠르게 걷기")
    }
    fly() {
        console.log("fly")
    }
}

const superman = new SuperMan(100,100);

superman.run()
superman.walk()
superman.fly()