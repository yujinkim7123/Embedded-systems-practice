const str = "ABCDEF[1599]AAQ";

const a = str.indexOf("[")
const b = str.indexOf("]")

const result = str.substring(a + 1, b)
// console.log(result)
const num = Number(result) + 1;
console.log(num)