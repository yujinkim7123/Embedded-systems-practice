let str = "";

for (let i = 1; i <= 9; i++){
    str += i
}

const input1 = 1
const input2 = 5
const result = str.substring(input1, input2);
console.log(result)