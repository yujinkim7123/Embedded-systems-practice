function erase(str, start, size) {
    let a = str.substring(0, start);
    let b = str.substring(start + size);
    return a + b;
  }
  let str = "ABCDEFGHIJK";
  let result = erase(str, 3, 5);
  console.log(result);
  
  
  