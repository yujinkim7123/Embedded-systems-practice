let str = "BTSMINBTSMINBTSKKOPSM";
let target = ["SM", "MIN", "OP", "VO", "TSM"];
let max = 0;
let maxStr;

function getCount(target) {
    let a = -1;
    let cnt = 0;
    while (1) {
        a = str.indexOf(target, a + 1);
        if (a === -1) break;
        cnt = cnt + 1;
    }
    return cnt
}



for (let i = 0; i < target.length; i++) {
    let cnt = getCount(target[i])
    if (cnt > max) {
        max = cnt
        maxStr = target[i]
    }
}

alert(maxStr)