const string = "ABCABCMCABCABCMCBBQABC";

let a = -1;
// 개수
let count = 0;

while (1) {
    a = string.indexOf("ABC", a + 1);
    // console.log(a)
    if (a === -1) break;
    count = count + 1;
}

console.log(count)