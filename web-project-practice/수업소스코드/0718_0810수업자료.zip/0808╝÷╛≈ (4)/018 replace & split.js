const str ="bts@macdonald.co.kr||inho@mincoding.co.kr||jason@jyp.com";

// co.kr / com을 모두 net으로 변경하기
str.replace(/co.kr|com/g, "net");

// bar \\ 구분 기호로 분류하기 

const arr = str.split("||");
console.log(arr)

let idArray = [];
// @로 파싱하기 
for(let i = 0; i < arr.length; i++){
    const index = arr[i].indexOf("@");
    const id = arr[i].substring(0, index);
    idArray.push(id);
}

console.log(idArray);