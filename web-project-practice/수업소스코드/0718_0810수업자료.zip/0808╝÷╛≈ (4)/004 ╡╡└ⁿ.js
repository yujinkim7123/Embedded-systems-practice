const a = "ABC";
const b = "BBQ";
const c = "ABC";

if (a === b === c) {
    alert("Very Good")
} else if (a !== b && a !== c) {
    alert("Only one")
} else {
    alert("Two")
}