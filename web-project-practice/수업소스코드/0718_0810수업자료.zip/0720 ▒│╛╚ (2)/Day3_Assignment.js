a = document.querySelectorAll(".nav_item");
const arr = []
for(let i of a)
{
    arr.push(i.innerText);
}