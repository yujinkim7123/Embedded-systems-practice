# 웹 풀스택 기술을 활용한 주문관리 시스템
사용한 기술 :  vue, node.js, express, mysql, nginx, aws 
