<template>
  <div>
    LIST입니다.
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
